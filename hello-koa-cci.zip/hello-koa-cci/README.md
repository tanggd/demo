## QuickStart

### Development

```bash
$ cd ../../
$ sh start_dubbo_service.sh
$ cd examples/hello-koa
$ yarn
$ yarn start
$ open http://localhost:3000/hello
```

### Requirement

- Node.js 8.x +
- Typescript 2.8+

### Attention

This example does not use a translator.
